package a05;

/*******************************************************************************
 * Author(s): Aaron Sadler, Gerald Brady 
 * Class: CSIS-2420
 * Professor: Margarethe Posch
 * Assignment: A05  KT-Trees
 ******************************************************************************/

public class PointST<Value> {
	
	 /**
	 * construct an empty symbol table of points 
	 */
	public PointST(){

	   }
	   
	 /**
	 * is the symbol table empty?
	 * 
	 * @return
	 */
	public boolean isEmpty(){
		return false;
 
	   }
	   
	 /**
	 * number of points
	 * 
	 * @return
	 */
	public int size(){
		return 0;

	   }
	   
	 /**
	 * associate the value val with point p
	 * 
	 * @param p
	 * @param val
	 */
	public void put(Point2D p, Value val){

	   }
	   
	 /**
	 * value associated with point p 
	 * 
	 * @param p
	 * @return
	 */
	public Value get(Point2D p){
		return null;
 
	   }
	   
	 /**
	 * does the symbol table contain point p?
	 * 
	 * @param p
	 * @return
	 */
	public boolean contains(Point2D p){
		return false;

	   }
	   
	 /**
	 * all points in the symbol table
	 * 
	 * @return
	 */
	public Iterable<Point2D> points(){
		return null;

	   }
	   
	 /**
	 * all points that are inside the rectangle
	 * 
	 * @param rect
	 * @return
	 */
	public Iterable<Point2D> range(RectHV rect){
		return null;

	   }
	   
	 /**
	 * a nearest neighbor to point p; null if the symbol table is empty 
	 * 
	 * @param p
	 * @return
	 */
	public Point2D nearest(Point2D p){
		return p;

	   }
	   
	   public static void main(String[] args){
		   // unit testing of the methods (not graded)
	   }
}